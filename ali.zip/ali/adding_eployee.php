﻿  <?php
           include("inculde/connection.php");
        include("inculde/header.php");
                   if(isset($_POST['btn_insert'])){
                          $name=$_POST['name'];
                          $fname=$_POST['fname'];
                          $lastname=$_POST['lastname'];
                          $jop=$_POST['jop'];

               $query="INSERT INTO empolyee (emp_name,emp_fname,emp_surename,emp_jop) VALUES ('$name','$fname','
               $lastname','$jop');";
                               mysqli_query($con,$query);
         if(!mysqli_query($con,$query)){
          header("location:add_emp.php");
         }
        
      }
  ?>
    <div class="container-fluid">

      <div class="row">
            <div class="col-md-8 col-md-offset-2" dir="rtl">
           <h1 id="title">  اضافه کردن کارمند جدید </h1>   <br />
          <form class="form-horizontal" method="post" action="">

              <div class="form-group">
              <div class="col-sm-10">
                          <input type="text " class="form-control" placeholder="نام کارمند" name="name" required>
                           </div>
                           <label class="col-sm-2 control-label">نام کارمند</label>
              </div>

              <div class="form-group">
              <div class="col-sm-10">
                         <input type="text" class="form-control" placeholder="نام پدر" name="fname" required>
                </div>
                        <label class="col-sm-2 control-label">نام پدر</label>
              </div>

              <div class="form-group">
              <div class="col-sm-10">
                        <input type="text" class="form-control" name="lastname" placeholder="تخلص"  required>
                </div>
                         <label class="col-sm-2 control-label">تخلص </label>
              </div>

              <div class="form-group">
              <div class="col-sm-10">
                         <input type="text" class="form-control"name="jop" placeholder="وظیفه" required>
                 </div>
                         <label class="col-sm-2 control-label"> وظیفه</label>
              </div>

              <div class="form-group">
                <div class="row">
                           <div class="col-md-2 col-md-offset-0.5">
                          <input type="submit" name="btn_insert" class="btn btn-info btn-block"  value=" افزودن ">
             </div>
                  <div class="col-md-6">
            </div>
                  <div class="col-md-2">
                              <a href="index.php" class="btn btn-info btn-block"> برگشت </a>
                  </div>
                </div>
             </div>
          </form>
        </div>
      </div>
    </div>


    <?php
      include("inculde/footer.php");
  ?>
 