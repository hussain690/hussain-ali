  <?php
      include("inculde/connection.php");
      include("inculde/header.php");

				  if(isset($_POST['serach'])){
				  $serach=$_POST['serach'];
				  $query="SELECT * from empolyee where concat(emp_id,emp_name,emp_fname,emp_surename,emp_jop)like'%$serach%'";
				  mysqli_set_charset($con,"utf8");
				  $result=mysqli_query($con,$query);
			}
        else
		{

		   $query="SELECT * from empolyee";
			mysqli_set_charset($con,"utf8");
			$result=mysqli_query($con,$query);

        }
  ?>


    <div class="container-fluid">


			  <div class="row">
				<div class="col-md-4" id="menu">
				  <ul class="nav nav-pills">
					<li role="presentation"><a href="add_emp.php">کارمند جدید </a></li>
					<li role="presentation"><a href="add_item.php">جنس جدید</a></li>
					<li role="presentation" class="active"><a href="#">لیست کارمندان</a></li>
					<li role="presentation"><a href="index.php">صفحه اصلی</a></li>
				  </ul>
        </div>
        <div class="col-md-6" id="serach">
					  <form class="form-inline" method="post" action="">
						<div class="form-group">
						  <div class="input-group">
							<input type="text" class="form-control"name="serach" placeholder="جستجو  ">
							<div class="input-group-addon"><a href="emp_list.php" class="glyphicon glyphicon-refresh"></a></div>
						  </div>
						  <input type="submit" value="جستجو" class="btn btn-success">
						</div>
					  </form>
        </div>
        <div class="col-md-2">
          <h3> لیست کارمندان </h3>
        </div>
      </div>
      <br />

      <div class="row">
        <div class="col-md-12">

          <table class="table table-striped" dir="rtl">
            <thead>
              <tr class="danger">
                <th>نام کارمند</th>
                <th>تخلص</th>
                <th>نام پدر</th>
                <th>وظیفه</th>
                <th>عملیات</th>
              </tr>
            </thead>

            <tbody>
						  <?php
						  $row=mysqli_fetch_assoc($result);
						  if($row){
							do{
							echo "<tr>";
							echo "<td>".$row['emp_name']."</td>";
							echo "<td>".$row['emp_surename']."</td>";
							echo "<td>".$row['emp_fname']."</td>";
							echo "<td>".$row['emp_jop']."</td>";
							echo "<td><a href='edit/edit_item?id=".$row['emp_id']."'>ویرایش  </a></td>";
							echo "</tr>";
							}
							while($row=mysqli_fetch_assoc($result));
						  }


						  ?>
            </tbody>

          </table>

        </div>
      </div>
    </div>
	
    <?php
	
          include("inculde/footer.php");
  ?>
