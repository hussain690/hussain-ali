<?php

    $con=mysqli_connect("localhost","root","","invertory");

           mysqli_set_charset($con,"utf8");
       if(!$con){

    	die("connection error".mysqli_connect_error());
    }

?>